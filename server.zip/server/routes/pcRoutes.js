// server/routes/pcRoutes.js
const express = require('express');
const { getAllPCs, addPC, updatePC, deletePC } = require('../controllers/pcController');

const router = express.Router();

router.get('/pcs', getAllPCs);
router.post('/pcs', addPC);
router.put('/pcs/:id', updatePC);
router.delete('/pcs/:id', deletePC);

module.exports = router;
