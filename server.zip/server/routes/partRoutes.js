// server/routes/partRoutes.js
const express = require('express');
const {
  getPartsByPC,
  addPart,
  updatePart,
  deletePart,
  searchParts
} = require('../controllers/partController');

const router = express.Router();

router.get('/parts/pc/:pcId', getPartsByPC);
router.post('/parts/pc/:pcId', addPart);
router.put('/parts/:id', updatePart);
router.delete('/parts/:id', deletePart);
router.get('/parts/search', searchParts);

module.exports = router;
