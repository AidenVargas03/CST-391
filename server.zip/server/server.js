// server/server.js
const express = require('express');
const cors = require('cors');
require('dotenv').config();

const pcRoutes = require('./routes/pcRoutes');
const partRoutes = require('./routes/partRoutes');

const app = express();

// Allow Vite dev server origins
app.use(cors({
  origin: ['http://localhost:5173', 'http://127.0.0.1:5173'],
  credentials: true
}));

app.use(express.json());

// API routes
app.use('/api', pcRoutes);
app.use('/api', partRoutes);

// Health check
app.get('/api/health', (_req, res) => res.json({ ok: true }));

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`API listening on http://localhost:${PORT}`);
});
