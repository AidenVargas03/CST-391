// server/controllers/pcController.js
const { pool } = require('../db');

exports.getAllPCs = async (_req, res) => {
  try {
    const [rows] = await pool.query('SELECT * FROM PC');
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Error fetching PCs' });
  }
};

exports.addPC = async (req, res) => {
  const { name, owner } = req.body;
  if (!name || !owner) {
    return res.status(400).json({ message: 'Name and Owner are required' });
  }
  try {
    const [result] = await pool.query(
      'INSERT INTO PC (name, owner) VALUES (?, ?)',
      [name, owner]
    );
    res.status(201).json({ id: result.insertId, name, owner });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Error adding PC' });
  }
};

exports.updatePC = async (req, res) => {
  const { id } = req.params;
  const { name, owner } = req.body;
  if (!name || !owner) {
    return res.status(400).json({ message: 'Name and Owner are required' });
  }
  try {
    await pool.query('UPDATE PC SET name = ?, owner = ? WHERE id = ?', [
      name,
      owner,
      id
    ]);
    res.sendStatus(200);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Error updating PC' });
  }
};

exports.deletePC = async (req, res) => {
  const { id } = req.params;
  try {
    await pool.query('DELETE FROM PC WHERE id = ?', [id]);
    res.sendStatus(200);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Error deleting PC' });
  }
};
