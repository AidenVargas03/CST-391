// server/controllers/partController.js
const { pool } = require('../db');

exports.getPartsByPC = async (req, res) => {
  const { pcId } = req.params;
  try {
    const [rows] = await pool.query('SELECT * FROM Part WHERE pc_id = ?', [pcId]);
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Error fetching parts' });
  }
};

exports.addPart = async (req, res) => {
  const { pcId } = req.params;
  const { name, type, price, quantity } = req.body;

  if (!name || !type || price == null || quantity == null) {
    return res.status(400).json({ message: 'All fields are required' });
  }

  try {
    const [result] = await pool.query(
      'INSERT INTO Part (pc_id, name, type, price, quantity) VALUES (?, ?, ?, ?, ?)',
      [pcId, name, type, price, quantity]
    );

    res.status(201).json({
      id: result.insertId,
      pcId: Number(pcId),
      name,
      type,
      price,
      quantity
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Error adding part' });
  }
};

exports.updatePart = async (req, res) => {
  const { id } = req.params;
  const { name, type, price, quantity } = req.body;

  if (!name || !type || price == null || quantity == null) {
    return res.status(400).json({ message: 'All fields are required' });
  }

  try {
    await pool.query(
      'UPDATE Part SET name = ?, type = ?, price = ?, quantity = ? WHERE id = ?',
      [name, type, price, quantity, id]
    );
    res.sendStatus(200);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Error updating part' });
  }
};

exports.deletePart = async (req, res) => {
  const { id } = req.params;
  try {
    await pool.query('DELETE FROM Part WHERE id = ?', [id]);
    res.sendStatus(200);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Error deleting part' });
  }
};

exports.searchParts = async (req, res) => {
  const { q } = req.query;
  try {
    const [rows] = await pool.query(
      'SELECT * FROM Part WHERE name LIKE ? OR type LIKE ?',
      [`%${q}%`, `%${q}%`]
    );
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Error searching parts' });
  }
};
