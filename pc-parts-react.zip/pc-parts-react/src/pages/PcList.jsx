import { useEffect, useState } from "react";
import PartList from "./PartList";

export default function PCList() {
  const [pcs, setPcs] = useState([]);
  const [selectedPcId, setSelectedPcId] = useState(null);

  useEffect(() => {
    fetch("http://localhost:3000/api/pcs")
      .then((res) => res.json())
      .then((data) => setPcs(data))
      .catch((err) => console.error(err));
  }, []);

  return (
    <div className="p-4">
      <h2 className="text-xl font-bold mb-4">PC List</h2>

      <ul className="space-y-2">
        {pcs.map((pc) => (
          <li
            key={pc.id}
            onClick={() => setSelectedPcId(pc.id)}
            className="cursor-pointer p-2 border rounded hover:bg-gray-100"
          >
            {pc.name} — {pc.owner}
          </li>
        ))}
      </ul>

      {selectedPcId && (
        <div className="mt-6">
          <h3 className="text-lg font-semibold mb-2">Parts for PC #{selectedPcId}</h3>
          <PartList pcId={selectedPcId} />
        </div>
      )}
    </div>
  );
}
