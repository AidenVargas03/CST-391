import { useState } from "react";

export default function AddPart() {
  const [pcId, setPcId] = useState("");
  const [name, setName] = useState("");
  const [type, setType] = useState("");
  const [price, setPrice] = useState("");
  const [quantity, setQuantity] = useState("");
  const API_BASE = import.meta.env.VITE_API_BASE;

  const handleSubmit = (e) => {
    e.preventDefault();
    fetch(`${API_BASE}/parts/pc/${pcId}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name, type, price: Number(price), quantity: Number(quantity) }),
    })
      .then((res) => res.json())
      .then(() => {
        alert("✅ Part added!");
        setPcId("");
        setName("");
        setType("");
        setPrice("");
        setQuantity("");
      })
      .catch((err) => console.error("Error adding part:", err));
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-2 p-4">
      <h2 className="text-xl font-bold">Add Part</h2>
      
      <input
        type="number"
        placeholder="PC ID"
        value={pcId}
        onChange={(e) => setPcId(e.target.value)}
        required
      />
      <input
        type="text"
        placeholder="Part Name"
        value={name}
        onChange={(e) => setName(e.target.value)}
        required
      />
      <input
        type="text"
        placeholder="Part Type"
        value={type}
        onChange={(e) => setType(e.target.value)}
        required
      />
      <input
        type="number"
        placeholder="Price"
        value={price}
        onChange={(e) => setPrice(e.target.value)}
        required
      />
      <input
        type="number"
        placeholder="Quantity"
        value={quantity}
        onChange={(e) => setQuantity(e.target.value)}
        required
      />

      <button type="submit" className="px-4 py-2 bg-blue-500 text-white rounded">
        Add Part
      </button>
    </form>
  );
}
