export default function Home() {
  return (
    <div>
      <h2>Welcome to PC Parts Manager</h2>
      <p>Manage your PCs and Parts easily.</p>
    </div>
  );
}
