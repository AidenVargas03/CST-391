import { useState } from "react";

export default function AddPc() {
  const [name, setName] = useState("");
  const [owner, setOwner] = useState("");
  const API_BASE = import.meta.env.VITE_API_BASE;

  const handleSubmit = (e) => {
    e.preventDefault();
    fetch(`${API_BASE}/pcs`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name, owner }),
    })
      .then((res) => res.json())
      .then((data) => {
        alert("✅ PC added!");
        setName("");
        setOwner("");
      })
      .catch((err) => console.error("Error adding PC:", err));
  };

  return (
    <form onSubmit={handleSubmit}>
      <h2>Add PC</h2>
      <input
        type="text"
        placeholder="PC Name"
        value={name}
        onChange={(e) => setName(e.target.value)}
        required
      />
      <input
        type="text"
        placeholder="Owner"
        value={owner}
        onChange={(e) => setOwner(e.target.value)}
        required
      />
      <button type="submit">Add</button>
    </form>
  );
}
