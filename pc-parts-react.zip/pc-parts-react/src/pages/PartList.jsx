import { useEffect, useState } from "react";

export default function PartList({ pcId }) {
  const [parts, setParts] = useState([]);

  useEffect(() => {
    if (!pcId) return;

    fetch(`http://localhost:3000/api/parts/pc/${pcId}`)
      .then((res) => res.json())
      .then((data) => setParts(data))
      .catch((err) => console.error(err));
  }, [pcId]);

  return (
    <div>
      <ul className="space-y-2">
        {parts.length > 0 ? (
          parts.map((part) => (
            <li key={part.id} className="p-2 border rounded">
              {part.name} ({part.type}) — ${part.price} x {part.quantity}
            </li>
          ))
        ) : (
          <p>No parts found for this PC.</p>
        )}
      </ul>
    </div>
  );
}
