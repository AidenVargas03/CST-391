import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Navbar from "./components/Navbar";
import Home from "./pages/Home";
import PcList from "./pages/PcList";
import AddPc from "./pages/AddPc";
import PartList from "./pages/PartList";
import AddPart from "./pages/AddPart";

function App() {
  return (
    <Router>
      <Navbar />
      <div className="container">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/pcs" element={<PcList />} />
          <Route path="/pcs/add" element={<AddPc />} />
          <Route path="/parts" element={<PartList />} />
          <Route path="/parts/add" element={<AddPart />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
